package com.Sultan.models;

/**
 * Created by Sagar on 6/14/2015.
 */
public class CardItemModel {

    public String title;
    public String content;

    public CardItemModel(String title, String content) {
        this.title = title;
        this.content = content;
    }
}
