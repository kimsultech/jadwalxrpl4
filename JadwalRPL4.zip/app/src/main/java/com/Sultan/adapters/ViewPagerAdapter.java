package com.Sultan.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;



public class ViewPagerAdapter extends FragmentPagerAdapter
{

	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return 0;
	}

	@Override
	public Fragment getItem(int p1)
	{
		// TODO: Implement this method
		return null;
	}


    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }
}
