package com.Sultan.hari;

import android.app.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v7.widget.*;
import android.view.*;
import com.Sultan.JadwalRPL4.*;

import android.support.v4.app.Fragment;

public class Kamis extends Fragment {

	private MainActivity mainActivity;
	private Toolbar toolbar;


    public Kamis() {
        // Required empty public constructor
    }

	@Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mainActivity = (MainActivity)activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.item_kamis, container, false);

		toolbar = (Toolbar)view.findViewById(R.id.kamis_toolbar);

        setupToolbar();

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mainActivity.setupNavigationDrawer(toolbar);
    }

    private void setupToolbar(){
        toolbar.setTitle(getString(R.string.kamis_title));
        mainActivity.setSupportActionBar(toolbar);
    }
}
